package com.example.callscreentheme.Model

class ImageListModel {

    var img = 0

    constructor(img: Int) {
        this.img = img

    }

    constructor(){

    }


}