package com.example.callscreentheme.Model

class NeonListModel {

    var neonimg = 0

    constructor(neonimg: Int) {
        this.neonimg = neonimg
    }

    constructor(){

    }


}