package com.example.callscreentheme.Model

class AstronomyListModel {

    var astroimg = 0

    constructor(astroimg: Int) {
        this.astroimg = astroimg
    }

        constructor()
        {

        }

}