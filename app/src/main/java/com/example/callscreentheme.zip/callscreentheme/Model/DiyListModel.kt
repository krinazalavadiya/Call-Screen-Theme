package com.example.callscreentheme.Model

class DiyListModel {

    var diyimg = 0

    constructor(diyimg: Int) {
        this.diyimg = diyimg
    }

    constructor()
    {

    }

}