package com.example.callscreentheme.Model

class HalloweenListModel {

    var hallimg = 0

    constructor(hallimg: Int) {
        this.hallimg = hallimg
    }

    constructor()
    {

    }

}