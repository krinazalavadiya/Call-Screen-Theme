package com.example.callscreentheme.Model

class NatureListModel {

    var natureimg = 0

    constructor(natureimg: Int) {
        this.natureimg = natureimg
    }

    constructor()
    {

    }

}