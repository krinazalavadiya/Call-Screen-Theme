package com.example.callscreentheme.Model

class MarvelListModel {

    var marvelimg = 0

    constructor(marvelimg: Int) {
        this.marvelimg = marvelimg
    }

    constructor()
    {

    }

}